const api = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImxmaHZ5empzcnZiZmVvYWF3cnliIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzE5ODcxMjIsImV4cCI6MjA0NzU2MzEyMn0.p5fWjxlfOQMnVvdrwNUL4Fy71DoAEBUmkUV7bFzjmw0";
const url='https://lfhvyzjsrvbfeoaawryb.supabase.co/rest/v1/firebooks?select=*';
let booksData = [];
let currentPage = 1;
const itemsPerPage = 4;
let filteredBooks = [];

fetch(url, {
 method: 'GET',
 headers: {
 'apikey': api,
 'Authorization': `Bearer ${api}`,
 'Content-Type': 'application/json',
 }
})
.then(response => {
 if (!response.ok) {
  throw new Error('Network response was not ok ' + response.statusText);
 }
  return response.json();
 })
 .then(data => {
  booksData = data;
  filteredBooks = data;
  displayBooks();
 })
 .catch(error => {
  console.error('There has been a problem with your fetch operation:', error);
 });

 function displayBooks() {
  const contenedor = document.getElementById('mostrar');
  contenedor.innerHTML = '';
  const start = (currentPage - 1) * itemsPerPage;
  const end = start + itemsPerPage;
  filteredBooks.slice(start, end).forEach(datos => {
  const name = datos.name;
  const link = datos.link;
  const photo = datos.url_photo;
  const info = `<div class="bk" data-title="${name}" data-link="${link}">
  <img data-src="${photo}" alt="${name}" class="lazy">
  <span>${name}</span>
  </div>`;
  contenedor.innerHTML += info;
  });
  loadImages();
  addClickEventToBooks();
  updatePagination();
 }

 function loadImages() {
  const lazyImages = document.querySelectorAll('img.lazy');
  lazyImages.forEach(img => {
  img.src = img.dataset.src;
  img.classList.remove('lazy');
  });
 }

 function addClickEventToBooks() {
  const books = document.querySelectorAll('.bk');
  books.forEach(book => {
  book.addEventListener('click', function() {
  const link = book.getAttribute('data-link');
  window.open(link, '_blank');
   });
  });
 }

 function updatePagination() {
  const totalPages = Math.ceil(filteredBooks.length / itemsPerPage);
  const pagination = document.getElementById('pagination');
  pagination.innerHTML = '';
  for (let i = 1; i <= totalPages; i++) {
   const pageButton = document.createElement('button');
   pageButton.textContent = i;
   pageButton.onclick = () => {
   currentPage = i;
   displayBooks();
  };
  pagination.appendChild(pageButton);
  }
 }

 document.getElementById('inp').addEventListener('keypress', function(event) {
 if (event.key === 'Enter') {
 searchBook();
 }
 });

 function searchBook() {
  const input = document.getElementById('inp').value.toLowerCase();
  filteredBooks = booksData.filter(book => book.name.toLowerCase().includes(input));
  currentPage = 1;
  displayBooks();
 }

 function resetSearch() {
  document.getElementById('inp').value = '';
  searchBook();
 }

function toggleMode() {
 const body = document.body;
 body.classList.toggle('dark-mode');
 document.getElementById('toggle-button').src = './src/icons/theme.svg'; 
}
